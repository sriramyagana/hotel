package com.capgemini.descoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DescoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
